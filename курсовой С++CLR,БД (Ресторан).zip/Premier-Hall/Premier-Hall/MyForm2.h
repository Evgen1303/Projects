#pragma once

namespace PremierHall {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm2
	/// </summary>
	public ref class MyForm2 : public System::Windows::Forms::Form
	{
	public:
		MyForm2(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm2()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:


	private: System::Data::DataSet^  dataSet1;
	private: System::Data::DataTable^  dataTable1;
	private: System::Data::DataColumn^  dataColumn1;
	private: System::Data::DataColumn^  dataColumn2;
	private: System::Data::DataColumn^  dataColumn3;
	private: System::Data::DataColumn^  dataColumn4;
	private: System::Data::DataColumn^  dataColumn5;
	private: System::Data::DataColumn^  dataColumn6;
	private: System::Windows::Forms::DataGridView^  dataGridView1;






	private: System::Data::OleDb::OleDbCommand^  oleDbSelectCommand1;
	private: System::Data::OleDb::OleDbConnection^  oleDbConnection1;
	private: System::Data::OleDb::OleDbDataAdapter^  oleDbDataAdapter1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idzakazuDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  pipDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  oplachenDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idstilDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  summaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;







	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm2::typeid));
			this->dataSet1 = (gcnew System::Data::DataSet());
			this->dataTable1 = (gcnew System::Data::DataTable());
			this->dataColumn1 = (gcnew System::Data::DataColumn());
			this->dataColumn2 = (gcnew System::Data::DataColumn());
			this->dataColumn3 = (gcnew System::Data::DataColumn());
			this->dataColumn4 = (gcnew System::Data::DataColumn());
			this->dataColumn5 = (gcnew System::Data::DataColumn());
			this->dataColumn6 = (gcnew System::Data::DataColumn());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->idzakazuDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->pipDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->oplachenDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->idstilDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->summaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->oleDbSelectCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbConnection1 = (gcnew System::Data::OleDb::OleDbConnection());
			this->oleDbDataAdapter1 = (gcnew System::Data::OleDb::OleDbDataAdapter());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataSet1
			// 
			this->dataSet1->DataSetName = L"NewDataSet";
			this->dataSet1->Tables->AddRange(gcnew cli::array< System::Data::DataTable^  >(1) { this->dataTable1 });
			// 
			// dataTable1
			// 
			this->dataTable1->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(6) {
				this->dataColumn1, this->dataColumn2,
					this->dataColumn3, this->dataColumn4, this->dataColumn5, this->dataColumn6
			});
			this->dataTable1->TableName = L"zakazu";
			// 
			// dataColumn1
			// 
			this->dataColumn1->Caption = L"�����";
			this->dataColumn1->ColumnName = L"id_zakazu";
			// 
			// dataColumn2
			// 
			this->dataColumn2->ColumnName = L"data";
			// 
			// dataColumn3
			// 
			this->dataColumn3->ColumnName = L"pip";
			// 
			// dataColumn4
			// 
			this->dataColumn4->ColumnName = L"oplachen";
			// 
			// dataColumn5
			// 
			this->dataColumn5->ColumnName = L"id_stil";
			// 
			// dataColumn6
			// 
			this->dataColumn6->ColumnName = L"summa";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoGenerateColumns = false;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(6) {
				this->idzakazuDataGridViewTextBoxColumn,
					this->dataDataGridViewTextBoxColumn, this->pipDataGridViewTextBoxColumn, this->oplachenDataGridViewTextBoxColumn, this->idstilDataGridViewTextBoxColumn,
					this->summaDataGridViewTextBoxColumn
			});
			this->dataGridView1->DataMember = L"zakazu";
			this->dataGridView1->DataSource = this->dataSet1;
			this->dataGridView1->Location = System::Drawing::Point(12, 12);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(644, 268);
			this->dataGridView1->TabIndex = 0;
			// 
			// idzakazuDataGridViewTextBoxColumn
			// 
			this->idzakazuDataGridViewTextBoxColumn->DataPropertyName = L"id_zakazu";
			this->idzakazuDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->idzakazuDataGridViewTextBoxColumn->Name = L"idzakazuDataGridViewTextBoxColumn";
			// 
			// dataDataGridViewTextBoxColumn
			// 
			this->dataDataGridViewTextBoxColumn->DataPropertyName = L"data";
			this->dataDataGridViewTextBoxColumn->HeaderText = L"����";
			this->dataDataGridViewTextBoxColumn->Name = L"dataDataGridViewTextBoxColumn";
			// 
			// pipDataGridViewTextBoxColumn
			// 
			this->pipDataGridViewTextBoxColumn->DataPropertyName = L"pip";
			this->pipDataGridViewTextBoxColumn->HeaderText = L"��������";
			this->pipDataGridViewTextBoxColumn->Name = L"pipDataGridViewTextBoxColumn";
			// 
			// oplachenDataGridViewTextBoxColumn
			// 
			this->oplachenDataGridViewTextBoxColumn->DataPropertyName = L"oplachen";
			this->oplachenDataGridViewTextBoxColumn->HeaderText = L"������";
			this->oplachenDataGridViewTextBoxColumn->Name = L"oplachenDataGridViewTextBoxColumn";
			// 
			// idstilDataGridViewTextBoxColumn
			// 
			this->idstilDataGridViewTextBoxColumn->DataPropertyName = L"id_stil";
			this->idstilDataGridViewTextBoxColumn->HeaderText = L"����� �����";
			this->idstilDataGridViewTextBoxColumn->Name = L"idstilDataGridViewTextBoxColumn";
			// 
			// summaDataGridViewTextBoxColumn
			// 
			this->summaDataGridViewTextBoxColumn->DataPropertyName = L"summa";
			this->summaDataGridViewTextBoxColumn->HeaderText = L"����";
			this->summaDataGridViewTextBoxColumn->Name = L"summaDataGridViewTextBoxColumn";
			// 
			// oleDbSelectCommand1
			// 
			this->oleDbSelectCommand1->CommandText = resources->GetString(L"oleDbSelectCommand1.CommandText");
			this->oleDbSelectCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbConnection1
			// 
			this->oleDbConnection1->ConnectionString = L"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Premierdata.mdb";
			// 
			// oleDbDataAdapter1
			// 
			this->oleDbDataAdapter1->SelectCommand = this->oleDbSelectCommand1;
			cli::array< System::Data::Common::DataColumnMapping^ >^ __mcTemp__1 = gcnew cli::array< System::Data::Common::DataColumnMapping^  >(6) {
				(gcnew System::Data::Common::DataColumnMapping(L"id_zakazu",
					L"id_zakazu")), (gcnew System::Data::Common::DataColumnMapping(L"data", L"data")), (gcnew System::Data::Common::DataColumnMapping(L"pip",
						L"pip")), (gcnew System::Data::Common::DataColumnMapping(L"oplachen", L"oplachen")), (gcnew System::Data::Common::DataColumnMapping(L"id_stil",
							L"id_stil")), (gcnew System::Data::Common::DataColumnMapping(L"summa", L"summa"))
			};
			this->oleDbDataAdapter1->TableMappings->AddRange(gcnew cli::array< System::Data::Common::DataTableMapping^  >(1) {
				(gcnew System::Data::Common::DataTableMapping(L"Table",
					L"oficiant", __mcTemp__1))
			});
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::DarkGreen;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Location = System::Drawing::Point(-4, 286);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(345, 49);
			this->button1->TabIndex = 1;
			this->button1->Text = L"�����";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm2::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::DarkRed;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(335, 286);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(345, 49);
			this->button2->TabIndex = 2;
			this->button2->Text = L"�����";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm2::button2_Click);
			// 
			// MyForm2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(666, 330);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->dataGridView1);
			this->Name = L"MyForm2";
			this->Text = L"������ ���������";
			this->Load += gcnew System::EventHandler(this, &MyForm2::MyForm2_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm2_Load(System::Object^  sender, System::EventArgs^  e) {
		oleDbDataAdapter1->Fill(dataTable1);
	}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	Application::Exit();
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();               // �������� �����
	Form^ form = this->Owner;  // �������� ��������� �� ��������� 
	form->Show();
}
};
}
