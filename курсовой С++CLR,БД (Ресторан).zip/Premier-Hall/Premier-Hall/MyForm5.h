#pragma once

namespace PremierHall {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm5
	/// </summary>
	public ref class MyForm5 : public System::Windows::Forms::Form
	{
	public:
		MyForm5(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm5()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  tabControl1;
	protected:
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::DataGridView^  dataGridView1;




	private: System::Data::DataSet^  dataSet1;
	private: System::Data::DataTable^  dataTable1;
	private: System::Data::DataColumn^  dataColumn1;
	private: System::Data::DataColumn^  dataColumn2;
	private: System::Data::DataColumn^  dataColumn3;
	private: System::Data::DataColumn^  dataColumn4;
	private: System::Windows::Forms::TabPage^  tabPage2;






	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::TextBox^  textBox6;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;

	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox1;







	private: System::Data::OleDb::OleDbCommand^  oleDbSelectCommand1;
	private: System::Data::OleDb::OleDbConnection^  oleDbConnection1;
	private: System::Data::OleDb::OleDbCommand^  oleDbInsertCommand1;
	private: System::Data::OleDb::OleDbCommand^  oleDbUpdateCommand1;
	private: System::Data::OleDb::OleDbCommand^  oleDbDeleteCommand1;
	private: System::Data::OleDb::OleDbDataAdapter^  oleDbDataAdapter1;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idstravuDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  nazvaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  cinaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  expr1DataGridViewTextBoxColumn;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Data::DataTable^  dataTable2;
	private: System::Data::DataColumn^  dataColumn5;
	private: System::Data::DataColumn^  dataColumn6;
	private: System::Windows::Forms::DataGridView^  dataGridView2;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::TextBox^  textBox8;
	private: System::Windows::Forms::TextBox^  textBox9;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::TextBox^  textBox7;


	private: System::Data::DataTable^  dataTable3;
	private: System::Data::DataColumn^  dataColumn7;
	private: System::Data::DataColumn^  dataColumn8;
	private: System::Data::DataColumn^  dataColumn9;
	private: System::Data::DataColumn^  dataColumn10;
	private: System::Windows::Forms::TabPage^  tabPage3;
	private: System::Windows::Forms::DataGridView^  dataGridView3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  idskladDataGridViewTextBoxColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  nazvaDataGridViewTextBoxColumn2;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  kilkistDataGridViewTextBoxColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  odnvumDataGridViewTextBoxColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  idingridientDataGridViewTextBoxColumn;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  nazvaDataGridViewTextBoxColumn1;
private: System::Windows::Forms::GroupBox^  groupBox5;
private: System::Windows::Forms::ComboBox^  comboBox3;
private: System::Windows::Forms::ComboBox^  comboBox2;
private: System::Windows::Forms::Button^  button7;
private: System::Windows::Forms::Label^  label7;
private: System::Windows::Forms::Label^  label11;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::TextBox^  textBox3;
private: System::Data::DataTable^  dataTable4;
private: System::Data::DataColumn^  dataColumn11;
private: System::Data::DataColumn^  dataColumn12;
private: System::Data::DataColumn^  dataColumn13;
private: System::Data::DataColumn^  dataColumn14;
private: System::Windows::Forms::GroupBox^  groupBox6;
private: System::Windows::Forms::TabPage^  tabPage4;
private: System::Windows::Forms::DataGridView^  dataGridView4;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  nazvaDataGridViewTextBoxColumn3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  expr1DataGridViewTextBoxColumn1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  kilkistDataGridViewTextBoxColumn1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  odnvumDataGridViewTextBoxColumn1;
private: System::Windows::Forms::GroupBox^  groupBox8;
private: System::Windows::Forms::GroupBox^  groupBox7;
private: System::Windows::Forms::ComboBox^  comboBox4;
private: System::Windows::Forms::ComboBox^  comboBox5;
private: System::Windows::Forms::Button^  button8;
private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::Label^  label14;
private: System::Windows::Forms::Label^  label15;

private: System::Windows::Forms::ComboBox^  comboBox6;
private: System::Windows::Forms::Label^  label16;
private: System::Windows::Forms::TextBox^  textBox10;
























	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm5::typeid));
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->idstravuDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->nazvaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->cinaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->expr1DataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataSet1 = (gcnew System::Data::DataSet());
			this->dataTable1 = (gcnew System::Data::DataTable());
			this->dataColumn1 = (gcnew System::Data::DataColumn());
			this->dataColumn2 = (gcnew System::Data::DataColumn());
			this->dataColumn3 = (gcnew System::Data::DataColumn());
			this->dataColumn4 = (gcnew System::Data::DataColumn());
			this->dataTable2 = (gcnew System::Data::DataTable());
			this->dataColumn5 = (gcnew System::Data::DataColumn());
			this->dataColumn6 = (gcnew System::Data::DataColumn());
			this->dataTable3 = (gcnew System::Data::DataTable());
			this->dataColumn7 = (gcnew System::Data::DataColumn());
			this->dataColumn8 = (gcnew System::Data::DataColumn());
			this->dataColumn9 = (gcnew System::Data::DataColumn());
			this->dataColumn10 = (gcnew System::Data::DataColumn());
			this->dataTable4 = (gcnew System::Data::DataTable());
			this->dataColumn11 = (gcnew System::Data::DataColumn());
			this->dataColumn12 = (gcnew System::Data::DataColumn());
			this->dataColumn13 = (gcnew System::Data::DataColumn());
			this->dataColumn14 = (gcnew System::Data::DataColumn());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->idingridientDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->nazvaDataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->idskladDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->nazvaDataGridViewTextBoxColumn2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->kilkistDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->odnvumDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->tabPage4 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox8 = (gcnew System::Windows::Forms::GroupBox());
			this->dataGridView4 = (gcnew System::Windows::Forms::DataGridView());
			this->nazvaDataGridViewTextBoxColumn3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->expr1DataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->kilkistDataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->odnvumDataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->groupBox7 = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox6 = (gcnew System::Windows::Forms::ComboBox());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox5 = (gcnew System::Windows::Forms::ComboBox());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->oleDbSelectCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbConnection1 = (gcnew System::Data::OleDb::OleDbConnection());
			this->oleDbInsertCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbUpdateCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDeleteCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDataAdapter1 = (gcnew System::Data::OleDb::OleDbDataAdapter());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->tabControl1->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable4))->BeginInit();
			this->tabPage2->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->BeginInit();
			this->tabPage3->SuspendLayout();
			this->groupBox6->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->BeginInit();
			this->groupBox5->SuspendLayout();
			this->tabPage4->SuspendLayout();
			this->groupBox8->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->BeginInit();
			this->groupBox7->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage3);
			this->tabControl1->Controls->Add(this->tabPage4);
			this->tabControl1->Location = System::Drawing::Point(2, 3);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(783, 390);
			this->tabControl1->TabIndex = 0;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->groupBox2);
			this->tabPage1->Controls->Add(this->groupBox1);
			this->tabPage1->Controls->Add(this->dataGridView1);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(775, 364);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"����";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this->groupBox2->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Controls->Add(this->label5);
			this->groupBox2->Controls->Add(this->label6);
			this->groupBox2->Controls->Add(this->textBox4);
			this->groupBox2->Controls->Add(this->textBox5);
			this->groupBox2->Controls->Add(this->textBox6);
			this->groupBox2->Location = System::Drawing::Point(470, 186);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(294, 175);
			this->groupBox2->TabIndex = 7;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"�������� ����� (��������� �� ����� � ������� �� ��������� \"�������� �����\")";
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::SaddleBrown;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(9, 130);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(279, 39);
			this->button2->TabIndex = 6;
			this->button2->Text = L"��������";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm5::button2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(6, 94);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(89, 18);
			this->label4->TabIndex = 5;
			this->label4->Text = L"��������:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(6, 62);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(47, 18);
			this->label5->TabIndex = 4;
			this->label5->Text = L"ֳ��:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(6, 30);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(61, 18);
			this->label6->TabIndex = 3;
			this->label6->Text = L"�����:";
			// 
			// textBox4
			// 
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox4->Location = System::Drawing::Point(113, 91);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(175, 24);
			this->textBox4->TabIndex = 2;
			// 
			// textBox5
			// 
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox5->Location = System::Drawing::Point(113, 59);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(175, 24);
			this->textBox5->TabIndex = 1;
			// 
			// textBox6
			// 
			this->textBox6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox6->Location = System::Drawing::Point(113, 27);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(175, 24);
			this->textBox6->TabIndex = 0;
			// 
			// groupBox1
			// 
			this->groupBox1->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox1->Controls->Add(this->comboBox1);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Location = System::Drawing::Point(470, 6);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(294, 175);
			this->groupBox1->TabIndex = 1;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"������ ����� (������ ���� �� ��������� \"������ �����\")";
			// 
			// comboBox1
			// 
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(8) {
				L"����� �� г�����", L"������� �������", L"������ �������",
					L"������ NEW", L"������ �\'���� ������", L"����� ������", L"����", L"�������"
			});
			this->comboBox1->Location = System::Drawing::Point(113, 91);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(175, 26);
			this->comboBox1->TabIndex = 7;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::SaddleBrown;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Location = System::Drawing::Point(9, 130);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(279, 39);
			this->button1->TabIndex = 6;
			this->button1->Text = L"������";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm5::button1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(6, 94);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(89, 18);
			this->label3->TabIndex = 5;
			this->label3->Text = L"��������:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(6, 62);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(47, 18);
			this->label2->TabIndex = 4;
			this->label2->Text = L"ֳ��:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(6, 30);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(61, 18);
			this->label1->TabIndex = 3;
			this->label1->Text = L"�����:";
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox2->Location = System::Drawing::Point(113, 59);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(175, 24);
			this->textBox2->TabIndex = 1;
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox1->Location = System::Drawing::Point(113, 27);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(175, 24);
			this->textBox1->TabIndex = 0;
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoGenerateColumns = false;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->idstravuDataGridViewTextBoxColumn,
					this->nazvaDataGridViewTextBoxColumn, this->cinaDataGridViewTextBoxColumn, this->expr1DataGridViewTextBoxColumn
			});
			this->dataGridView1->DataMember = L"menu";
			this->dataGridView1->DataSource = this->dataSet1;
			this->dataGridView1->Location = System::Drawing::Point(6, 6);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(455, 349);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm5::dataGridView1_MouseClick);
			// 
			// idstravuDataGridViewTextBoxColumn
			// 
			this->idstravuDataGridViewTextBoxColumn->DataPropertyName = L"id_stravu";
			this->idstravuDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->idstravuDataGridViewTextBoxColumn->Name = L"idstravuDataGridViewTextBoxColumn";
			// 
			// nazvaDataGridViewTextBoxColumn
			// 
			this->nazvaDataGridViewTextBoxColumn->DataPropertyName = L"nazva";
			this->nazvaDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->nazvaDataGridViewTextBoxColumn->Name = L"nazvaDataGridViewTextBoxColumn";
			// 
			// cinaDataGridViewTextBoxColumn
			// 
			this->cinaDataGridViewTextBoxColumn->DataPropertyName = L"cina";
			this->cinaDataGridViewTextBoxColumn->HeaderText = L"ֳ��";
			this->cinaDataGridViewTextBoxColumn->Name = L"cinaDataGridViewTextBoxColumn";
			// 
			// expr1DataGridViewTextBoxColumn
			// 
			this->expr1DataGridViewTextBoxColumn->DataPropertyName = L"Expr1";
			this->expr1DataGridViewTextBoxColumn->HeaderText = L"��������";
			this->expr1DataGridViewTextBoxColumn->Name = L"expr1DataGridViewTextBoxColumn";
			// 
			// dataSet1
			// 
			this->dataSet1->DataSetName = L"NewDataSet";
			this->dataSet1->Tables->AddRange(gcnew cli::array< System::Data::DataTable^  >(4) {
				this->dataTable1, this->dataTable2, this->dataTable3,
					this->dataTable4
			});
			// 
			// dataTable1
			// 
			this->dataTable1->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(4) {
				this->dataColumn1, this->dataColumn2,
					this->dataColumn3, this->dataColumn4
			});
			this->dataTable1->TableName = L"menu";
			// 
			// dataColumn1
			// 
			this->dataColumn1->ColumnName = L"id_stravu";
			// 
			// dataColumn2
			// 
			this->dataColumn2->ColumnName = L"nazva";
			// 
			// dataColumn3
			// 
			this->dataColumn3->ColumnName = L"cina";
			// 
			// dataColumn4
			// 
			this->dataColumn4->ColumnName = L"Expr1";
			// 
			// dataTable2
			// 
			this->dataTable2->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(2) { this->dataColumn5, this->dataColumn6 });
			this->dataTable2->TableName = L"ingridient";
			// 
			// dataColumn5
			// 
			this->dataColumn5->ColumnName = L"id_ingridient";
			// 
			// dataColumn6
			// 
			this->dataColumn6->ColumnName = L"nazva";
			// 
			// dataTable3
			// 
			this->dataTable3->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(4) {
				this->dataColumn7, this->dataColumn8,
					this->dataColumn9, this->dataColumn10
			});
			this->dataTable3->TableName = L"sklad";
			// 
			// dataColumn7
			// 
			this->dataColumn7->ColumnName = L"id_sklad";
			// 
			// dataColumn8
			// 
			this->dataColumn8->ColumnName = L"nazva";
			// 
			// dataColumn9
			// 
			this->dataColumn9->ColumnName = L"kilkist";
			// 
			// dataColumn10
			// 
			this->dataColumn10->ColumnName = L"odn_vum";
			// 
			// dataTable4
			// 
			this->dataTable4->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(4) {
				this->dataColumn11, this->dataColumn12,
					this->dataColumn13, this->dataColumn14
			});
			this->dataTable4->TableName = L"sklad_stravu";
			// 
			// dataColumn11
			// 
			this->dataColumn11->ColumnName = L"nazva";
			// 
			// dataColumn12
			// 
			this->dataColumn12->ColumnName = L"Expr1";
			// 
			// dataColumn13
			// 
			this->dataColumn13->ColumnName = L"kilkist";
			// 
			// dataColumn14
			// 
			this->dataColumn14->ColumnName = L"odn_vum";
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->groupBox4);
			this->tabPage2->Controls->Add(this->groupBox3);
			this->tabPage2->Controls->Add(this->dataGridView2);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(775, 364);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"����䳺���";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this->groupBox4->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox4->Controls->Add(this->button6);
			this->groupBox4->Controls->Add(this->label8);
			this->groupBox4->Controls->Add(this->label10);
			this->groupBox4->Controls->Add(this->textBox8);
			this->groupBox4->Controls->Add(this->textBox9);
			this->groupBox4->Location = System::Drawing::Point(371, 177);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(392, 181);
			this->groupBox4->TabIndex = 8;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"�������� ����� (��������� �� ����� � ������� �� ��������� \"�������� �����\")";
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::SaddleBrown;
			this->button6->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button6->ForeColor = System::Drawing::Color::White;
			this->button6->Location = System::Drawing::Point(9, 107);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(377, 39);
			this->button6->TabIndex = 6;
			this->button6->Text = L"��������";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm5::button6_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label8->Location = System::Drawing::Point(6, 62);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(61, 18);
			this->label8->TabIndex = 4;
			this->label8->Text = L"�����:";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label10->Location = System::Drawing::Point(6, 30);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(65, 18);
			this->label10->TabIndex = 3;
			this->label10->Text = L"�����:";
			// 
			// textBox8
			// 
			this->textBox8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox8->Location = System::Drawing::Point(113, 59);
			this->textBox8->Name = L"textBox8";
			this->textBox8->Size = System::Drawing::Size(273, 24);
			this->textBox8->TabIndex = 1;
			// 
			// textBox9
			// 
			this->textBox9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox9->Location = System::Drawing::Point(113, 27);
			this->textBox9->Name = L"textBox9";
			this->textBox9->Size = System::Drawing::Size(273, 24);
			this->textBox9->TabIndex = 0;
			// 
			// groupBox3
			// 
			this->groupBox3->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox3->Controls->Add(this->button5);
			this->groupBox3->Controls->Add(this->label9);
			this->groupBox3->Controls->Add(this->textBox7);
			this->groupBox3->Location = System::Drawing::Point(371, 6);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(392, 165);
			this->groupBox3->TabIndex = 2;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"������ ����� (������ ���� �� ��������� \"������ �����\")";
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::SaddleBrown;
			this->button5->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button5->ForeColor = System::Drawing::Color::White;
			this->button5->Location = System::Drawing::Point(9, 66);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(377, 39);
			this->button5->TabIndex = 6;
			this->button5->Text = L"������";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm5::button5_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label9->Location = System::Drawing::Point(6, 30);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(61, 18);
			this->label9->TabIndex = 3;
			this->label9->Text = L"�����:";
			// 
			// textBox7
			// 
			this->textBox7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox7->Location = System::Drawing::Point(113, 27);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(273, 24);
			this->textBox7->TabIndex = 0;
			// 
			// dataGridView2
			// 
			this->dataGridView2->AutoGenerateColumns = false;
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {
				this->idingridientDataGridViewTextBoxColumn,
					this->nazvaDataGridViewTextBoxColumn1
			});
			this->dataGridView2->DataMember = L"ingridient";
			this->dataGridView2->DataSource = this->dataSet1;
			this->dataGridView2->Location = System::Drawing::Point(6, 6);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->Size = System::Drawing::Size(359, 352);
			this->dataGridView2->TabIndex = 0;
			this->dataGridView2->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm5::dataGridView2_MouseClick);
			// 
			// idingridientDataGridViewTextBoxColumn
			// 
			this->idingridientDataGridViewTextBoxColumn->DataPropertyName = L"id_ingridient";
			this->idingridientDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->idingridientDataGridViewTextBoxColumn->Name = L"idingridientDataGridViewTextBoxColumn";
			// 
			// nazvaDataGridViewTextBoxColumn1
			// 
			this->nazvaDataGridViewTextBoxColumn1->DataPropertyName = L"nazva";
			this->nazvaDataGridViewTextBoxColumn1->HeaderText = L"�����";
			this->nazvaDataGridViewTextBoxColumn1->Name = L"nazvaDataGridViewTextBoxColumn1";
			// 
			// tabPage3
			// 
			this->tabPage3->Controls->Add(this->groupBox6);
			this->tabPage3->Controls->Add(this->groupBox5);
			this->tabPage3->Location = System::Drawing::Point(4, 22);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Padding = System::Windows::Forms::Padding(3);
			this->tabPage3->Size = System::Drawing::Size(775, 364);
			this->tabPage3->TabIndex = 2;
			this->tabPage3->Text = L"�����";
			this->tabPage3->UseVisualStyleBackColor = true;
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->dataGridView3);
			this->groupBox6->Location = System::Drawing::Point(2, -1);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(473, 359);
			this->groupBox6->TabIndex = 3;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = L"�������� ���� \"�������\" ����� ������������� ������� �������� � �������";
			// 
			// dataGridView3
			// 
			this->dataGridView3->AutoGenerateColumns = false;
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->idskladDataGridViewTextBoxColumn,
					this->nazvaDataGridViewTextBoxColumn2, this->kilkistDataGridViewTextBoxColumn, this->odnvumDataGridViewTextBoxColumn
			});
			this->dataGridView3->DataMember = L"sklad";
			this->dataGridView3->DataSource = this->dataSet1;
			this->dataGridView3->Location = System::Drawing::Point(4, 19);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->Size = System::Drawing::Size(454, 334);
			this->dataGridView3->TabIndex = 0;
			this->dataGridView3->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm5::dataGridView3_MouseClick);
			// 
			// idskladDataGridViewTextBoxColumn
			// 
			this->idskladDataGridViewTextBoxColumn->DataPropertyName = L"id_sklad";
			this->idskladDataGridViewTextBoxColumn->HeaderText = L"id_sklad";
			this->idskladDataGridViewTextBoxColumn->Name = L"idskladDataGridViewTextBoxColumn";
			// 
			// nazvaDataGridViewTextBoxColumn2
			// 
			this->nazvaDataGridViewTextBoxColumn2->DataPropertyName = L"nazva";
			this->nazvaDataGridViewTextBoxColumn2->HeaderText = L"nazva";
			this->nazvaDataGridViewTextBoxColumn2->Name = L"nazvaDataGridViewTextBoxColumn2";
			// 
			// kilkistDataGridViewTextBoxColumn
			// 
			this->kilkistDataGridViewTextBoxColumn->DataPropertyName = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn->HeaderText = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn->Name = L"kilkistDataGridViewTextBoxColumn";
			// 
			// odnvumDataGridViewTextBoxColumn
			// 
			this->odnvumDataGridViewTextBoxColumn->DataPropertyName = L"odn_vum";
			this->odnvumDataGridViewTextBoxColumn->HeaderText = L"odn_vum";
			this->odnvumDataGridViewTextBoxColumn->Name = L"odnvumDataGridViewTextBoxColumn";
			// 
			// groupBox5
			// 
			this->groupBox5->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox5->Controls->Add(this->comboBox3);
			this->groupBox5->Controls->Add(this->comboBox2);
			this->groupBox5->Controls->Add(this->button7);
			this->groupBox5->Controls->Add(this->label7);
			this->groupBox5->Controls->Add(this->label11);
			this->groupBox5->Controls->Add(this->label12);
			this->groupBox5->Controls->Add(this->textBox3);
			this->groupBox5->Location = System::Drawing::Point(475, 6);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(294, 175);
			this->groupBox5->TabIndex = 2;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"������ ����� (������ ���� �� ��������� \"������ �����\")";
			// 
			// comboBox3
			// 
			this->comboBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(47) {
				L"������", L"��������", L"����", L"����� ������",
					L"������ ����", L"���� �����", L"��������", L"��������", L"������� �������", L"������� �����", L"��� ��", L"��� �������", L"����������",
					L"��������", L"���", L"������ ������", L"������ ������", L"������ ��������", L"����", L"��������", L"�������", L"������� ������",
					L"������ ������", L"Գ�� ������", L"������ ����", L"���������� ������", L"����� �����", L"������", L"�������� ����", L"����� ���������",
					L"��������", L"�����", L"������������", L"�����", L"�����", L"��������", L"��� ��", L"��� �������", L"�\'����� ������", L"��� � �������",
					L"��� �����������", L"����������", L"��������", L"���", L"�������", L"��������", L"���� Pesto"
			});
			this->comboBox3->Location = System::Drawing::Point(113, 27);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(175, 26);
			this->comboBox3->TabIndex = 8;
			// 
			// comboBox2
			// 
			this->comboBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(5) { L"��.", L"��.", L"��.", L"����.", L"��." });
			this->comboBox2->Location = System::Drawing::Point(113, 91);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(175, 26);
			this->comboBox2->TabIndex = 7;
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::SaddleBrown;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button7->ForeColor = System::Drawing::Color::White;
			this->button7->Location = System::Drawing::Point(9, 130);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(279, 39);
			this->button7->TabIndex = 6;
			this->button7->Text = L"������";
			this->button7->UseVisualStyleBackColor = false;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm5::button7_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label7->Location = System::Drawing::Point(6, 94);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(58, 18);
			this->label7->TabIndex = 5;
			this->label7->Text = L"����:";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label11->Location = System::Drawing::Point(6, 62);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(86, 18);
			this->label11->TabIndex = 4;
			this->label11->Text = L"ʳ������:";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label12->Location = System::Drawing::Point(6, 30);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(61, 18);
			this->label12->TabIndex = 3;
			this->label12->Text = L"�����:";
			// 
			// textBox3
			// 
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox3->Location = System::Drawing::Point(113, 59);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(175, 24);
			this->textBox3->TabIndex = 1;
			// 
			// tabPage4
			// 
			this->tabPage4->Controls->Add(this->groupBox8);
			this->tabPage4->Controls->Add(this->groupBox7);
			this->tabPage4->Location = System::Drawing::Point(4, 22);
			this->tabPage4->Name = L"tabPage4";
			this->tabPage4->Padding = System::Windows::Forms::Padding(3);
			this->tabPage4->Size = System::Drawing::Size(775, 364);
			this->tabPage4->TabIndex = 3;
			this->tabPage4->Text = L"����� - ������";
			this->tabPage4->UseVisualStyleBackColor = true;
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->dataGridView4);
			this->groupBox8->Location = System::Drawing::Point(4, 4);
			this->groupBox8->Name = L"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(465, 354);
			this->groupBox8->TabIndex = 4;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = L"�������� ���� \"�������\" ����� ������������� ������� �������� � �������";
			// 
			// dataGridView4
			// 
			this->dataGridView4->AutoGenerateColumns = false;
			this->dataGridView4->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView4->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->nazvaDataGridViewTextBoxColumn3,
					this->expr1DataGridViewTextBoxColumn1, this->kilkistDataGridViewTextBoxColumn1, this->odnvumDataGridViewTextBoxColumn1
			});
			this->dataGridView4->DataMember = L"sklad_stravu";
			this->dataGridView4->DataSource = this->dataSet1;
			this->dataGridView4->Location = System::Drawing::Point(6, 19);
			this->dataGridView4->Name = L"dataGridView4";
			this->dataGridView4->Size = System::Drawing::Size(451, 329);
			this->dataGridView4->TabIndex = 0;
			this->dataGridView4->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm5::dataGridView4_MouseClick);
			// 
			// nazvaDataGridViewTextBoxColumn3
			// 
			this->nazvaDataGridViewTextBoxColumn3->DataPropertyName = L"nazva";
			this->nazvaDataGridViewTextBoxColumn3->HeaderText = L"nazva";
			this->nazvaDataGridViewTextBoxColumn3->Name = L"nazvaDataGridViewTextBoxColumn3";
			// 
			// expr1DataGridViewTextBoxColumn1
			// 
			this->expr1DataGridViewTextBoxColumn1->DataPropertyName = L"Expr1";
			this->expr1DataGridViewTextBoxColumn1->HeaderText = L"Expr1";
			this->expr1DataGridViewTextBoxColumn1->Name = L"expr1DataGridViewTextBoxColumn1";
			// 
			// kilkistDataGridViewTextBoxColumn1
			// 
			this->kilkistDataGridViewTextBoxColumn1->DataPropertyName = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn1->HeaderText = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn1->Name = L"kilkistDataGridViewTextBoxColumn1";
			// 
			// odnvumDataGridViewTextBoxColumn1
			// 
			this->odnvumDataGridViewTextBoxColumn1->DataPropertyName = L"odn_vum";
			this->odnvumDataGridViewTextBoxColumn1->HeaderText = L"odn_vum";
			this->odnvumDataGridViewTextBoxColumn1->Name = L"odnvumDataGridViewTextBoxColumn1";
			// 
			// groupBox7
			// 
			this->groupBox7->BackColor = System::Drawing::Color::LemonChiffon;
			this->groupBox7->Controls->Add(this->comboBox6);
			this->groupBox7->Controls->Add(this->label16);
			this->groupBox7->Controls->Add(this->comboBox4);
			this->groupBox7->Controls->Add(this->comboBox5);
			this->groupBox7->Controls->Add(this->button8);
			this->groupBox7->Controls->Add(this->label13);
			this->groupBox7->Controls->Add(this->label14);
			this->groupBox7->Controls->Add(this->label15);
			this->groupBox7->Controls->Add(this->textBox10);
			this->groupBox7->Location = System::Drawing::Point(475, 6);
			this->groupBox7->Name = L"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(294, 203);
			this->groupBox7->TabIndex = 3;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = L"������ ����� (������ ���� �� ��������� \"������ �����\")";
			// 
			// comboBox6
			// 
			this->comboBox6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox6->FormattingEnabled = true;
			this->comboBox6->Items->AddRange(gcnew cli::array< System::Object^  >(5) { L"��.", L"��.", L"��.", L"����.", L"��." });
			this->comboBox6->Location = System::Drawing::Point(113, 122);
			this->comboBox6->Name = L"comboBox6";
			this->comboBox6->Size = System::Drawing::Size(175, 26);
			this->comboBox6->TabIndex = 10;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label16->Location = System::Drawing::Point(6, 125);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(58, 18);
			this->label16->TabIndex = 9;
			this->label16->Text = L"����:";
			// 
			// comboBox4
			// 
			this->comboBox4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(47) {
				L"������", L"��������", L"����", L"����� ������",
					L"������ ����", L"���� �����", L"��������", L"��������", L"������� �������", L"������� �����", L"��� ��", L"��� �������", L"����������",
					L"��������", L"���", L"������ ������", L"������ ������", L"������ ��������", L"����", L"��������", L"�������", L"������� ������",
					L"������ ������", L"Գ�� ������", L"������ ����", L"���������� ������", L"����� �����", L"������", L"�������� ����", L"����� ���������",
					L"��������", L"�����", L"������������", L"�����", L"�����", L"��������", L"��� ��", L"��� �������", L"�\'����� ������", L"��� � �������",
					L"��� �����������", L"����������", L"��������", L"���", L"�������", L"��������", L"���� Pesto"
			});
			this->comboBox4->Location = System::Drawing::Point(113, 59);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(175, 26);
			this->comboBox4->TabIndex = 8;
			// 
			// comboBox5
			// 
			this->comboBox5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox5->FormattingEnabled = true;
			this->comboBox5->Items->AddRange(gcnew cli::array< System::Object^  >(30) {
				L"����������", L"�������� Medium", L"Medium well",
					L"Well done", L"Գ�� ̳���� �� �������� ������", L"������ ���� � ����������� ��������", L"������� ��������� � ���������", L"������ ������� � �����-��������� ����",
					L"������ ������ ����������� �������� �� ���������", L"�\'��� ������", L"���������� ������ \"������\"", L"�������� \"Premier\"",
					L"�������� ������", L"������", L"ҳ����� PREMIER", L"������ � ����������", L"����� � ��������������", L"�������� � ������",
					L"���������", L"г����� � �������", L"г����� � �������", L"������� \"Premier\"", L"������� \"�������\"", L"������� ����� TOWINE",
					L"������� � ������", L"������� � ��������", L"������� \"�������\"", L"������ � �������", L"������� �����", L"�������� �����"
			});
			this->comboBox5->Location = System::Drawing::Point(113, 27);
			this->comboBox5->Name = L"comboBox5";
			this->comboBox5->Size = System::Drawing::Size(175, 26);
			this->comboBox5->TabIndex = 7;
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::SaddleBrown;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button8->ForeColor = System::Drawing::Color::White;
			this->button8->Location = System::Drawing::Point(9, 154);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(279, 39);
			this->button8->TabIndex = 6;
			this->button8->Text = L"������";
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm5::button8_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label13->Location = System::Drawing::Point(6, 94);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(86, 18);
			this->label13->TabIndex = 5;
			this->label13->Text = L"ʳ������:";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label14->Location = System::Drawing::Point(6, 62);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(86, 18);
			this->label14->TabIndex = 4;
			this->label14->Text = L"����䳺��:";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label15->Location = System::Drawing::Point(6, 30);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(69, 18);
			this->label15->TabIndex = 3;
			this->label15->Text = L"������:";
			// 
			// textBox10
			// 
			this->textBox10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox10->Location = System::Drawing::Point(113, 91);
			this->textBox10->Name = L"textBox10";
			this->textBox10->Size = System::Drawing::Size(175, 24);
			this->textBox10->TabIndex = 1;
			// 
			// oleDbSelectCommand1
			// 
			this->oleDbSelectCommand1->CommandText = resources->GetString(L"oleDbSelectCommand1.CommandText");
			this->oleDbSelectCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbConnection1
			// 
			this->oleDbConnection1->ConnectionString = L"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Premierdata.mdb";
			// 
			// oleDbInsertCommand1
			// 
			this->oleDbInsertCommand1->CommandText = L"INSERT INTO sklad\r\n                         (id_ingridient, kilkist, id_vumiru)\r\n"
				L"VALUES        (20, 2, 3)";
			this->oleDbInsertCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbUpdateCommand1
			// 
			this->oleDbUpdateCommand1->CommandText = L"UPDATE       sklad\r\nSET                id_ingridient = 26, kilkist = 5, id_vumiru"
				L" = 3\r\nWHERE        (id_sklad = 26)";
			this->oleDbUpdateCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbDeleteCommand1
			// 
			this->oleDbDeleteCommand1->CommandText = L"DELETE FROM ingridient\r\nWHERE        (id_ingridient = 52)";
			this->oleDbDeleteCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbDataAdapter1
			// 
			this->oleDbDataAdapter1->DeleteCommand = this->oleDbDeleteCommand1;
			this->oleDbDataAdapter1->InsertCommand = this->oleDbInsertCommand1;
			this->oleDbDataAdapter1->SelectCommand = this->oleDbSelectCommand1;
			cli::array< System::Data::Common::DataColumnMapping^ >^ __mcTemp__1 = gcnew cli::array< System::Data::Common::DataColumnMapping^  >(4) {
				(gcnew System::Data::Common::DataColumnMapping(L"id_stravu",
					L"id_stravu")), (gcnew System::Data::Common::DataColumnMapping(L"nazva", L"nazva")), (gcnew System::Data::Common::DataColumnMapping(L"cina",
						L"cina")), (gcnew System::Data::Common::DataColumnMapping(L"kategory", L"kategory"))
			};
			this->oleDbDataAdapter1->TableMappings->AddRange(gcnew cli::array< System::Data::Common::DataTableMapping^  >(1) {
				(gcnew System::Data::Common::DataTableMapping(L"Table",
					L"menu", __mcTemp__1))
			});
			this->oleDbDataAdapter1->UpdateCommand = this->oleDbUpdateCommand1;
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::DarkGreen;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button3->ForeColor = System::Drawing::Color::White;
			this->button3->Location = System::Drawing::Point(2, 395);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(381, 48);
			this->button3->TabIndex = 1;
			this->button3->Text = L"�����";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm5::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::DarkRed;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button4->ForeColor = System::Drawing::Color::White;
			this->button4->Location = System::Drawing::Point(382, 395);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(399, 48);
			this->button4->TabIndex = 2;
			this->button4->Text = L"�����";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm5::button4_Click);
			// 
			// MyForm5
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(781, 444);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->tabControl1);
			this->Name = L"MyForm5";
			this->Text = L"��������������";
			this->Load += gcnew System::EventHandler(this, &MyForm5::MyForm5_Load);
			this->tabControl1->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable4))->EndInit();
			this->tabPage2->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->EndInit();
			this->tabPage3->ResumeLayout(false);
			this->groupBox6->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->EndInit();
			this->groupBox5->ResumeLayout(false);
			this->groupBox5->PerformLayout();
			this->tabPage4->ResumeLayout(false);
			this->groupBox8->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->EndInit();
			this->groupBox7->ResumeLayout(false);
			this->groupBox7->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
		// ������ 
	private: System::Void MyForm5_Load(System::Object^  sender, System::EventArgs^  e) {// �������� �����
		this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
			L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
			L"y = kategory.id_kategory)";
		oleDbDataAdapter1->Fill(dataTable1);

		this->oleDbSelectCommand1->CommandText = L"SELECT        id_ingridient, nazva\r\nFROM            ingridient";
		oleDbDataAdapter1->Fill(dataTable2);

		this->oleDbSelectCommand1->CommandText = L"SELECT        sklad.id_sklad, ingridient.nazva, sklad.kilkist, odn_vumiru.odn_vum\r\n"
			L" FROM((sklad INNER JOIN\r\n"
			L"odn_vumiru ON sklad.id_vumiru = odn_vumiru.id_vumiru) INNER JOIN\r\n"
			L"ingridient ON sklad.id_sklad = ingridient.id_ingridient)";
		oleDbDataAdapter1->Fill(dataTable3);

		this->oleDbSelectCommand1->CommandText = L"	SELECT        menu.nazva, ingridient.nazva AS Expr1, sklad_stravu.kilkist, odn_vumiru.odn_vum "
			L" FROM(((sklad_stravu INNER JOIN "
			L"	menu ON sklad_stravu.strava = menu.id_stravu) INNER JOIN "
			L"	ingridient ON sklad_stravu.ingridient = ingridient.id_ingridient) INNER JOIN "
			L"	odn_vumiru ON sklad_stravu.id_vumiru = odn_vumiru.id_vumiru) ";
		oleDbDataAdapter1->Fill(dataTable4);
	}
			 // ������� �� ������ ��������
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	int n;
	n = Convert::ToInt32(comboBox1->SelectedIndex) + 1;
	this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
		L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
		L"y = kategory.id_kategory)";
	this->oleDbInsertCommand1->CommandText = L"INSERT INTO menu\r\n                         (nazva, cina, kategory)\r\nVALUES       "
		L" ('"+ textBox1->Text +"', "+ textBox2->Text +", "+ n +")";

	oleDbConnection1->Open();
	oleDbDataAdapter1->InsertCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["menu"]);
	dataTable1->Clear();
	oleDbDataAdapter1->Fill(dataTable1);

	String^ message = "����� ������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox1->Text = "";
	textBox2->Text = "";
	comboBox1->Text = "";
}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
		L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
		L"y = kategory.id_kategory)";
	String^ n;
	int j;
	int k;

	j = dataGridView1->CurrentRow->Index;
	k = dataGridView1->CurrentCell->ColumnIndex;

	n = (String^)dataGridView1->Rows[j]->Cells[0]->Value;
	this->oleDbDeleteCommand1->CommandText = L"DELETE FROM menu\r\nWHERE        (id_stravu = "+ n +")";

	oleDbConnection1->Open();
	oleDbDataAdapter1->DeleteCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["menu"]);
	dataTable1->Clear();
	oleDbDataAdapter1->Fill(dataTable1);

	String^ message = "����� ��������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox4->Text = "";
	textBox5->Text = "";
	textBox6->Text = "";

}
		 // ������ ���� �� �������
private: System::Void dataGridView1_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	String^ n;
	int j;
	int k;

	j = dataGridView1->CurrentRow->Index;
	k = dataGridView1->CurrentCell->ColumnIndex;

	
	textBox6->Text = (String^)dataGridView1->Rows[j]->Cells[1]->Value;
	textBox5->Text = (String^)dataGridView1->Rows[j]->Cells[2]->Value;
	textBox4->Text = (String^)dataGridView1->Rows[j]->Cells[3]->Value;



}
		 //�����
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
	Application::Exit();
}
		 // �����
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Hide();               // �������� �����
	Form^ form = this->Owner;  // �������� ��������� �� ��������� 
	form->Show();
}
		// ������ ��������
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
	this->oleDbInsertCommand1->CommandText = L"INSERT INTO ingridient\r\n                         (nazva)\r\nVALUES        ('"+ textBox7->Text +"')";
	this->oleDbSelectCommand1->CommandText = L"SELECT        id_ingridient, nazva\r\nFROM            ingridient";
	

	oleDbConnection1->Open();
	oleDbDataAdapter1->InsertCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["ingridient"]);
	dataTable2->Clear();
	oleDbDataAdapter1->Fill(dataTable2);

	String^ message = "����� ������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox7->Text = "";


}
		 // ������ �������
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {

	this->oleDbSelectCommand1->CommandText = L"SELECT        id_ingridient, nazva\r\nFROM            ingridient";
	String^ n;
	int j;
	int k;

	j = dataGridView2->CurrentRow->Index;
	k = dataGridView2->CurrentCell->ColumnIndex;

	n = (String^)dataGridView2->Rows[j]->Cells[0]->Value;
	this->oleDbDeleteCommand1->CommandText = L"DELETE FROM ingridient\r\nWHERE        (id_ingridient = "+n+")";

	oleDbConnection1->Open();
	oleDbDataAdapter1->DeleteCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["ingridient"]);
	dataTable2->Clear();
	oleDbDataAdapter1->Fill(dataTable2);

	String^ message = "����� ��������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox8->Text = "";
	textBox9->Text = "";
	

}
private: System::Void dataGridView2_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {// ������� �� �������
	int j;
	int k;

	j = dataGridView2->CurrentRow->Index;
	k = dataGridView2->CurrentCell->ColumnIndex;


	textBox8->Text = (String^)dataGridView2->Rows[j]->Cells[0]->Value;
	textBox9->Text = (String^)dataGridView2->Rows[j]->Cells[1]->Value;
}
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
	
	this->oleDbSelectCommand1->CommandText = L"SELECT        sklad.id_sklad, ingridient.nazva, sklad.kilkist, odn_vumiru.odn_vum\r\n"
		L" FROM((sklad INNER JOIN\r\n"
		L"odn_vumiru ON sklad.id_vumiru = odn_vumiru.id_vumiru) INNER JOIN\r\n"
		L"ingridient ON sklad.id_sklad = ingridient.id_ingridient)";
	int n;
	n = Convert::ToInt32(comboBox2->SelectedIndex) + 1;
	this->oleDbInsertCommand1->CommandText = L"INSERT INTO sklad\r\n                         (id_ingridient, kilkist,id_vumiru)\r\n"
		L"VALUES        (" + comboBox3->SelectedIndex + 1 + ",  " + textBox3->Text + ", " + n + ")";
	oleDbConnection1->Open();
	oleDbDataAdapter1->InsertCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["sklad"]);
	dataTable3->Clear();
	oleDbDataAdapter1->Fill(dataTable3);

	String^ message = "����� ������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox3->Text = "";
	comboBox3->Text = "";
	comboBox2->Text = "";


}
private: System::Void dataGridView3_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	int j1 = dataGridView3->CurrentRow->Index;
	int k1 = dataGridView3->CurrentCell->ColumnIndex;

	this->oleDbUpdateCommand1->CommandText = L"UPDATE       sklad\r\nSET               kilkist = " + (String^)dataGridView3->Rows[j1]->Cells[2]->Value + " WHERE        (id_sklad = " + (String^)dataGridView3->Rows[j1]->Cells[0]->Value + ")";
	oleDbConnection1->Open();
	oleDbDataAdapter1->UpdateCommand->ExecuteNonQuery();
	oleDbConnection1->Close();

}


private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e) {
	this->oleDbSelectCommand1->CommandText = L"	SELECT        menu.nazva, ingridient.nazva AS Expr1, sklad_stravu.kilkist, odn_vumiru.odn_vum "
		L" FROM(((sklad_stravu INNER JOIN "
		L"	menu ON sklad_stravu.strava = menu.id_stravu) INNER JOIN "
		L"	ingridient ON sklad_stravu.ingridient = ingridient.id_ingridient) INNER JOIN "
		L"	odn_vumiru ON sklad_stravu.id_vumiru = odn_vumiru.id_vumiru) ";
	
	int n;
	n = Convert::ToInt32(comboBox5->SelectedIndex) + 5;
	this->oleDbInsertCommand1->CommandText = L"INSERT INTO sklad_stravu\r\n                         (strava, ingridient,kilkist,id_vumiru)\r\n"
		L"VALUES        (" + n + ",  " + comboBox4->SelectedIndex+ 1 + ", " + textBox10->Text + ","+ comboBox6->SelectedIndex+1+")";
	oleDbConnection1->Open();
	oleDbDataAdapter1->InsertCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["sklad_stravu"]);
	dataTable4->Clear();
	oleDbDataAdapter1->Fill(dataTable4);

	String^ message = "����� ������";
	String^ caption = "����";
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	comboBox5->Text = "";
	comboBox4->Text = "";
	textBox10->Text = "";
	comboBox6->Text = "";

}
private: System::Void dataGridView4_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	int j1 = dataGridView4->CurrentRow->Index;
	int k1 = dataGridView4->CurrentCell->ColumnIndex;
	int index;
	index = dataGridView4->CurrentRow->Index;

	this->oleDbUpdateCommand1->CommandText = L"UPDATE       sklad_stravu\r\nSET               kilkist = " + (String^)dataGridView4->Rows[j1]->Cells[2]->Value + " WHERE        (strava = " + index + ")";
	oleDbConnection1->Open();
	oleDbDataAdapter1->UpdateCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
}
};
}
