#pragma once

namespace PremierHall {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm3
	/// </summary>
	public ref class MyForm3 : public System::Windows::Forms::Form
	{
	public:
		MyForm3(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm3()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox1;
	protected:
	private: System::Windows::Forms::Button^  button1;

	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Data::OleDb::OleDbCommand^  oleDbSelectCommand1;
	private: System::Data::OleDb::OleDbConnection^  oleDbConnection1;
	private: System::Data::OleDb::OleDbCommand^  oleDbUpdateCommand1;
	private: System::Data::OleDb::OleDbCommand^  oleDbDeleteCommand1;
	private: System::Data::OleDb::OleDbDataAdapter^  oleDbDataAdapter1;
	private: System::Data::DataSet^  dataSet1;
	private: System::Data::DataTable^  dataTable1;
	private: System::Data::DataColumn^  dataColumn1;


	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  ssumDataGridViewTextBoxColumn;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;







	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->oleDbSelectCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbConnection1 = (gcnew System::Data::OleDb::OleDbConnection());
			this->oleDbUpdateCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDeleteCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDataAdapter1 = (gcnew System::Data::OleDb::OleDbDataAdapter());
			this->dataSet1 = (gcnew System::Data::DataSet());
			this->dataTable1 = (gcnew System::Data::DataTable());
			this->dataColumn1 = (gcnew System::Data::DataColumn());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->ssumDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->groupBox1->Location = System::Drawing::Point(5, 0);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(431, 160);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"������ �����";
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(253, 30);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(164, 31);
			this->textBox2->TabIndex = 8;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(38, 30);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(164, 31);
			this->textBox1->TabIndex = 7;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(130, 92);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(152, 35);
			this->button1->TabIndex = 5;
			this->button1->Text = L"�����������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm3::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(208, 33);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(39, 25);
			this->label2->TabIndex = 3;
			this->label2->Text = L"��";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(7, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(25, 25);
			this->label1->TabIndex = 1;
			this->label1->Text = L"�";
			// 
			// oleDbSelectCommand1
			// 
			this->oleDbSelectCommand1->CommandText = L"SELECT        SUM(summa) AS ssum\r\nFROM            zakazu\r\nWHERE        (data BETW"
				L"EEN \'14.06.2018\' AND \'16.06.2018\')";
			this->oleDbSelectCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbConnection1
			// 
			this->oleDbConnection1->ConnectionString = L"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Premierdata.mdb";
			// 
			// oleDbUpdateCommand1
			// 
			this->oleDbUpdateCommand1->CommandText = L"UPDATE `zakazu` SET `data` = \?, `summa` = \? WHERE (((\? = 1 AND `data` IS NULL) OR"
				L" (`data` = \?)) AND ((\? = 1 AND `summa` IS NULL) OR (`summa` = \?)) AND (`id_zakaz"
				L"u` = \?))";
			this->oleDbUpdateCommand1->Connection = this->oleDbConnection1;
			this->oleDbUpdateCommand1->Parameters->AddRange(gcnew cli::array< System::Data::OleDb::OleDbParameter^  >(7) {
				(gcnew System::Data::OleDb::OleDbParameter(L"data",
					System::Data::OleDb::OleDbType::VarWChar, 0, L"data")), (gcnew System::Data::OleDb::OleDbParameter(L"summa", System::Data::OleDb::OleDbType::Double,
						0, L"summa")), (gcnew System::Data::OleDb::OleDbParameter(L"IsNull_data", System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input,
							static_cast<System::Byte>(0), static_cast<System::Byte>(0), L"data", System::Data::DataRowVersion::Original, true, nullptr)),
							(gcnew System::Data::OleDb::OleDbParameter(L"Original_data", System::Data::OleDb::OleDbType::VarWChar, 0, System::Data::ParameterDirection::Input,
								false, static_cast<System::Byte>(0), static_cast<System::Byte>(0), L"data", System::Data::DataRowVersion::Original, nullptr)),
								(gcnew System::Data::OleDb::OleDbParameter(L"IsNull_summa", System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input,
									static_cast<System::Byte>(0), static_cast<System::Byte>(0), L"summa", System::Data::DataRowVersion::Original, true, nullptr)),
									(gcnew System::Data::OleDb::OleDbParameter(L"Original_summa", System::Data::OleDb::OleDbType::Double, 0, System::Data::ParameterDirection::Input,
										false, static_cast<System::Byte>(0), static_cast<System::Byte>(0), L"summa", System::Data::DataRowVersion::Original, nullptr)),
										(gcnew System::Data::OleDb::OleDbParameter(L"Original_id_zakazu", System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input,
											false, static_cast<System::Byte>(0), static_cast<System::Byte>(0), L"id_zakazu", System::Data::DataRowVersion::Original,
											nullptr))
			});
			// 
			// oleDbDeleteCommand1
			// 
			this->oleDbDeleteCommand1->CommandText = L"DELETE FROM `zakazu` WHERE (((\? = 1 AND `data` IS NULL) OR (`data` = \?)) AND ((\? "
				L"= 1 AND `summa` IS NULL) OR (`summa` = \?)) AND (`id_zakazu` = \?))";
			this->oleDbDeleteCommand1->Connection = this->oleDbConnection1;
			this->oleDbDeleteCommand1->Parameters->AddRange(gcnew cli::array< System::Data::OleDb::OleDbParameter^  >(5) {
				(gcnew System::Data::OleDb::OleDbParameter(L"IsNull_data",
					System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, static_cast<System::Byte>(0), static_cast<System::Byte>(0),
					L"data", System::Data::DataRowVersion::Original, true, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_data",
						System::Data::OleDb::OleDbType::VarWChar, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
						static_cast<System::Byte>(0), L"data", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"IsNull_summa",
							System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, static_cast<System::Byte>(0), static_cast<System::Byte>(0),
							L"summa", System::Data::DataRowVersion::Original, true, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_summa",
								System::Data::OleDb::OleDbType::Double, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
								static_cast<System::Byte>(0), L"summa", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_id_zakazu",
									System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
									static_cast<System::Byte>(0), L"id_zakazu", System::Data::DataRowVersion::Original, nullptr))
			});
			// 
			// oleDbDataAdapter1
			// 
			this->oleDbDataAdapter1->DeleteCommand = this->oleDbDeleteCommand1;
			this->oleDbDataAdapter1->SelectCommand = this->oleDbSelectCommand1;
			cli::array< System::Data::Common::DataColumnMapping^ >^ __mcTemp__1 = gcnew cli::array< System::Data::Common::DataColumnMapping^  >(3) {
				(gcnew System::Data::Common::DataColumnMapping(L"data",
					L"data")), (gcnew System::Data::Common::DataColumnMapping(L"summa", L"summa")), (gcnew System::Data::Common::DataColumnMapping(L"id_zakazu",
						L"id_zakazu"))
			};
			this->oleDbDataAdapter1->TableMappings->AddRange(gcnew cli::array< System::Data::Common::DataTableMapping^  >(1) {
				(gcnew System::Data::Common::DataTableMapping(L"Table",
					L"zakazu", __mcTemp__1))
			});
			this->oleDbDataAdapter1->UpdateCommand = this->oleDbUpdateCommand1;
			// 
			// dataSet1
			// 
			this->dataSet1->DataSetName = L"NewDataSet";
			this->dataSet1->Tables->AddRange(gcnew cli::array< System::Data::DataTable^  >(1) { this->dataTable1 });
			// 
			// dataTable1
			// 
			this->dataTable1->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(1) { this->dataColumn1 });
			this->dataTable1->TableName = L"zakazu";
			// 
			// dataColumn1
			// 
			this->dataColumn1->ColumnName = L"ssum";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoGenerateColumns = false;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->ssumDataGridViewTextBoxColumn });
			this->dataGridView1->DataMember = L"zakazu";
			this->dataGridView1->DataSource = this->dataSet1;
			this->dataGridView1->Location = System::Drawing::Point(442, 12);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(184, 148);
			this->dataGridView1->TabIndex = 1;
			// 
			// ssumDataGridViewTextBoxColumn
			// 
			this->ssumDataGridViewTextBoxColumn->DataPropertyName = L"ssum";
			this->ssumDataGridViewTextBoxColumn->HeaderText = L"�������:";
			this->ssumDataGridViewTextBoxColumn->Name = L"ssumDataGridViewTextBoxColumn";
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::DarkGreen;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button3->ForeColor = System::Drawing::Color::White;
			this->button3->Location = System::Drawing::Point(0, 171);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(320, 46);
			this->button3->TabIndex = 3;
			this->button3->Text = L"�����";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm3::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::DarkRed;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button4->ForeColor = System::Drawing::Color::White;
			this->button4->Location = System::Drawing::Point(318, 171);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(320, 46);
			this->button4->TabIndex = 4;
			this->button4->Text = L"�����";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm3::button4_Click);
			// 
			// MyForm3
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(631, 217);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->groupBox1);
			this->Name = L"MyForm3";
			this->Text = L"������� ��������� �� ���� �� �����";
			this->Load += gcnew System::EventHandler(this, &MyForm3::MyForm3_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
		// ������ 
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) { // ������� �� ������ ���������
	String^ date1;
	String^ date2;
	date1 = textBox1->Text;
	date2 = textBox2->Text;
	this->oleDbSelectCommand1->CommandText = L"SELECT        SUM(summa) AS ssum\r\nFROM            zakazu\r\nWHERE        (data "
		L"BETWEEN \'"+ date1 + " 00:00:00" +"\' AND \'"+ date2 + " 23:00:00" +"\')";
	oleDbDataAdapter1->Fill(dataTable1);
}

private: System::Void MyForm3_Load(System::Object^  sender, System::EventArgs^  e) {

	
}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) { // ������ �����
	this->Hide();               // �������� �����
	Form^ form = this->Owner;  // �������� ��������� �� ��������� 
	form->Show();
}
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {// ������ �����
	Application::Exit();
}
};
}
