#pragma once
#include <ctime>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
namespace PremierHall {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm4
	/// </summary>
	public ref class MyForm4 : public System::Windows::Forms::Form
	{
	public:
		MyForm4(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm4()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Data::OleDb::OleDbCommand^  oleDbSelectCommand1;
	protected:
	private: System::Data::OleDb::OleDbConnection^  oleDbConnection1;
	private: System::Data::OleDb::OleDbCommand^  oleDbInsertCommand1;
	private: System::Data::OleDb::OleDbCommand^  oleDbUpdateCommand1;
	private: System::Data::OleDb::OleDbCommand^  oleDbDeleteCommand1;
	private: System::Data::OleDb::OleDbDataAdapter^  oleDbDataAdapter1;
	private: System::Data::DataSet^  dataSet1;
	private: System::Data::DataTable^  dataTable1;
	private: System::Data::DataColumn^  dataColumn1;
	private: System::Data::DataColumn^  dataColumn2;
	private: System::Data::DataColumn^  dataColumn3;
	private: System::Data::DataColumn^  dataColumn4;
	private: System::Windows::Forms::DataGridView^  dataGridView1;




	private: System::Windows::Forms::GroupBox^  groupBox1;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Data::DataTable^  dataTable2;
	private: System::Data::DataColumn^  dataColumn5;
	private: System::Data::DataColumn^  dataColumn6;
	private: System::Data::DataColumn^  dataColumn7;
	private: System::Data::DataColumn^  dataColumn8;
	private: System::Data::DataColumn^  dataColumn9;
	private: System::Data::DataColumn^  dataColumn10;
	private: System::Windows::Forms::DataGridView^  dataGridView2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idzakazuDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idoficiantDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  oplachenDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idstilDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  summaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::TextBox^  textBox2;




	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idstravuDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  nazvaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  cinaDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  expr1DataGridViewTextBoxColumn;
	private: System::Data::DataTable^  dataTable3;
	private: System::Data::DataColumn^  dataColumn11;
	private: System::Data::DataColumn^  dataColumn12;
	private: System::Data::DataColumn^  dataColumn13;
	private: System::Data::DataColumn^  dataColumn14;
	private: System::Windows::Forms::DataGridView^  dataGridView3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idskladDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idingridientDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  kilkistDataGridViewTextBoxColumn;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  idvumiruDataGridViewTextBoxColumn;






	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)//������������� ����������� ����������
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm4::typeid));
			this->oleDbSelectCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbConnection1 = (gcnew System::Data::OleDb::OleDbConnection());
			this->oleDbInsertCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbUpdateCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDeleteCommand1 = (gcnew System::Data::OleDb::OleDbCommand());
			this->oleDbDataAdapter1 = (gcnew System::Data::OleDb::OleDbDataAdapter());
			this->dataSet1 = (gcnew System::Data::DataSet());
			this->dataTable1 = (gcnew System::Data::DataTable());
			this->dataColumn1 = (gcnew System::Data::DataColumn());
			this->dataColumn2 = (gcnew System::Data::DataColumn());
			this->dataColumn3 = (gcnew System::Data::DataColumn());
			this->dataColumn4 = (gcnew System::Data::DataColumn());
			this->dataTable2 = (gcnew System::Data::DataTable());
			this->dataColumn5 = (gcnew System::Data::DataColumn());
			this->dataColumn6 = (gcnew System::Data::DataColumn());
			this->dataColumn7 = (gcnew System::Data::DataColumn());
			this->dataColumn8 = (gcnew System::Data::DataColumn());
			this->dataColumn9 = (gcnew System::Data::DataColumn());
			this->dataColumn10 = (gcnew System::Data::DataColumn());
			this->dataTable3 = (gcnew System::Data::DataTable());
			this->dataColumn11 = (gcnew System::Data::DataColumn());
			this->dataColumn12 = (gcnew System::Data::DataColumn());
			this->dataColumn13 = (gcnew System::Data::DataColumn());
			this->dataColumn14 = (gcnew System::Data::DataColumn());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->idstravuDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->nazvaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->cinaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->expr1DataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->idzakazuDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->idoficiantDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->oplachenDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->idstilDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->summaDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->idskladDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->idingridientDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->kilkistDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->idvumiruDataGridViewTextBoxColumn = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->BeginInit();
			this->SuspendLayout();
			// 
			// oleDbSelectCommand1
			// 
			this->oleDbSelectCommand1->CommandText = resources->GetString(L"oleDbSelectCommand1.CommandText");
			this->oleDbSelectCommand1->Connection = this->oleDbConnection1;
			// 
			// oleDbConnection1
			// 
			this->oleDbConnection1->ConnectionString = L"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Premierdata.mdb";
			// 
			// oleDbInsertCommand1
			// 
			this->oleDbInsertCommand1->CommandText = L"INSERT INTO zakazu\r\n                         (data, id_oficiant, oplachen, id_sti"
				L"l, summa)\r\nVALUES        (NOW(), \?, \?, \?, \?)";
			this->oleDbInsertCommand1->Connection = this->oleDbConnection1;
			this->oleDbInsertCommand1->Parameters->AddRange(gcnew cli::array< System::Data::OleDb::OleDbParameter^  >(4) {
				(gcnew System::Data::OleDb::OleDbParameter(L"id_oficiant",
					System::Data::OleDb::OleDbType::Integer, 0, L"id_oficiant")), (gcnew System::Data::OleDb::OleDbParameter(L"oplachen", System::Data::OleDb::OleDbType::Boolean,
						2, L"oplachen")), (gcnew System::Data::OleDb::OleDbParameter(L"id_stil", System::Data::OleDb::OleDbType::Integer, 0, L"id_stil")),
						(gcnew System::Data::OleDb::OleDbParameter(L"summa", System::Data::OleDb::OleDbType::Double, 0, System::Data::ParameterDirection::Input,
							false, static_cast<System::Byte>(15), static_cast<System::Byte>(0), L"summa", System::Data::DataRowVersion::Current, nullptr))
			});
			// 
			// oleDbUpdateCommand1
			// 
			this->oleDbUpdateCommand1->CommandText = resources->GetString(L"oleDbUpdateCommand1.CommandText");
			this->oleDbUpdateCommand1->Connection = this->oleDbConnection1;
			this->oleDbUpdateCommand1->Parameters->AddRange(gcnew cli::array< System::Data::OleDb::OleDbParameter^  >(12) {
				(gcnew System::Data::OleDb::OleDbParameter(L"Original_Param1",
					System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
					static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param2",
						System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
						static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param3",
							System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
							static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param4",
								System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
								static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param5",
									System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
									static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param6",
										System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
										static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param7",
											System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
											static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param8",
												System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
												static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param9",
													System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
													static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param10",
														System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
														static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param11",
															System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
															static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_Param12",
																System::Data::OleDb::OleDbType::VarChar, 1024, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
																static_cast<System::Byte>(0), L"", System::Data::DataRowVersion::Original, nullptr))
			});
			// 
			// oleDbDeleteCommand1
			// 
			this->oleDbDeleteCommand1->CommandText = resources->GetString(L"oleDbDeleteCommand1.CommandText");
			this->oleDbDeleteCommand1->Connection = this->oleDbConnection1;
			this->oleDbDeleteCommand1->Parameters->AddRange(gcnew cli::array< System::Data::OleDb::OleDbParameter^  >(7) {
				(gcnew System::Data::OleDb::OleDbParameter(L"Original_id_stravu",
					System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
					static_cast<System::Byte>(0), L"id_stravu", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"IsNull_nazva",
						System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, static_cast<System::Byte>(0), static_cast<System::Byte>(0),
						L"nazva", System::Data::DataRowVersion::Original, true, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_nazva",
							System::Data::OleDb::OleDbType::VarWChar, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
							static_cast<System::Byte>(0), L"nazva", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"IsNull_cina",
								System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, static_cast<System::Byte>(0), static_cast<System::Byte>(0),
								L"cina", System::Data::DataRowVersion::Original, true, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_cina",
									System::Data::OleDb::OleDbType::Double, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
									static_cast<System::Byte>(0), L"cina", System::Data::DataRowVersion::Original, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"IsNull_kategory",
										System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, static_cast<System::Byte>(0), static_cast<System::Byte>(0),
										L"kategory", System::Data::DataRowVersion::Original, true, nullptr)), (gcnew System::Data::OleDb::OleDbParameter(L"Original_kategory",
											System::Data::OleDb::OleDbType::Integer, 0, System::Data::ParameterDirection::Input, false, static_cast<System::Byte>(0),
											static_cast<System::Byte>(0), L"kategory", System::Data::DataRowVersion::Original, nullptr))
			});
			// 
			// oleDbDataAdapter1
			// 
			this->oleDbDataAdapter1->DeleteCommand = this->oleDbDeleteCommand1;
			this->oleDbDataAdapter1->InsertCommand = this->oleDbInsertCommand1;
			this->oleDbDataAdapter1->SelectCommand = this->oleDbSelectCommand1;
			cli::array< System::Data::Common::DataColumnMapping^ >^ __mcTemp__1 = gcnew cli::array< System::Data::Common::DataColumnMapping^  >(4) {
				(gcnew System::Data::Common::DataColumnMapping(L"id_stravu",
					L"id_stravu")), (gcnew System::Data::Common::DataColumnMapping(L"nazva", L"nazva")), (gcnew System::Data::Common::DataColumnMapping(L"cina",
						L"cina")), (gcnew System::Data::Common::DataColumnMapping(L"kategory", L"kategory"))
			};
			this->oleDbDataAdapter1->TableMappings->AddRange(gcnew cli::array< System::Data::Common::DataTableMapping^  >(1) {
				(gcnew System::Data::Common::DataTableMapping(L"Table",
					L"menu", __mcTemp__1))
			});
			this->oleDbDataAdapter1->UpdateCommand = this->oleDbUpdateCommand1;
			// 
			// dataSet1
			// 
			this->dataSet1->DataSetName = L"NewDataSet";
			this->dataSet1->Tables->AddRange(gcnew cli::array< System::Data::DataTable^  >(3) { this->dataTable1, this->dataTable2, this->dataTable3 });
			// 
			// dataTable1
			// 
			this->dataTable1->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(4) {
				this->dataColumn1, this->dataColumn2,
					this->dataColumn3, this->dataColumn4
			});
			this->dataTable1->TableName = L"menu";
			// 
			// dataColumn1
			// 
			this->dataColumn1->ColumnName = L"id_stravu";
			// 
			// dataColumn2
			// 
			this->dataColumn2->ColumnName = L"nazva";
			// 
			// dataColumn3
			// 
			this->dataColumn3->ColumnName = L"cina";
			// 
			// dataColumn4
			// 
			this->dataColumn4->ColumnName = L"Expr1";
			// 
			// dataTable2
			// 
			this->dataTable2->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(6) {
				this->dataColumn5, this->dataColumn6,
					this->dataColumn7, this->dataColumn8, this->dataColumn9, this->dataColumn10
			});
			this->dataTable2->TableName = L"zakazu";
			// 
			// dataColumn5
			// 
			this->dataColumn5->ColumnName = L"id_zakazu";
			// 
			// dataColumn6
			// 
			this->dataColumn6->ColumnName = L"data";
			// 
			// dataColumn7
			// 
			this->dataColumn7->ColumnName = L"id_oficiant";
			// 
			// dataColumn8
			// 
			this->dataColumn8->ColumnName = L"oplachen";
			// 
			// dataColumn9
			// 
			this->dataColumn9->ColumnName = L"id_stil";
			// 
			// dataColumn10
			// 
			this->dataColumn10->ColumnName = L"summa";
			// 
			// dataTable3
			// 
			this->dataTable3->Columns->AddRange(gcnew cli::array< System::Data::DataColumn^  >(4) {
				this->dataColumn11, this->dataColumn12,
					this->dataColumn13, this->dataColumn14
			});
			this->dataTable3->TableName = L"sklad";
			// 
			// dataColumn11
			// 
			this->dataColumn11->ColumnName = L"id_sklad";
			// 
			// dataColumn12
			// 
			this->dataColumn12->ColumnName = L"id_ingridient";
			// 
			// dataColumn13
			// 
			this->dataColumn13->ColumnName = L"kilkist";
			// 
			// dataColumn14
			// 
			this->dataColumn14->ColumnName = L"id_vumiru";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoGenerateColumns = false;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->idstravuDataGridViewTextBoxColumn,
					this->nazvaDataGridViewTextBoxColumn, this->cinaDataGridViewTextBoxColumn, this->expr1DataGridViewTextBoxColumn
			});
			this->dataGridView1->DataMember = L"menu";
			this->dataGridView1->DataSource = this->dataSet1;
			this->dataGridView1->Location = System::Drawing::Point(6, 64);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(456, 210);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm4::dataGridView1_MouseClick);
			// 
			// idstravuDataGridViewTextBoxColumn
			// 
			this->idstravuDataGridViewTextBoxColumn->DataPropertyName = L"id_stravu";
			this->idstravuDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->idstravuDataGridViewTextBoxColumn->Name = L"idstravuDataGridViewTextBoxColumn";
			// 
			// nazvaDataGridViewTextBoxColumn
			// 
			this->nazvaDataGridViewTextBoxColumn->DataPropertyName = L"nazva";
			this->nazvaDataGridViewTextBoxColumn->HeaderText = L"�����";
			this->nazvaDataGridViewTextBoxColumn->Name = L"nazvaDataGridViewTextBoxColumn";
			// 
			// cinaDataGridViewTextBoxColumn
			// 
			this->cinaDataGridViewTextBoxColumn->DataPropertyName = L"cina";
			this->cinaDataGridViewTextBoxColumn->HeaderText = L"ֳ��";
			this->cinaDataGridViewTextBoxColumn->Name = L"cinaDataGridViewTextBoxColumn";
			// 
			// expr1DataGridViewTextBoxColumn
			// 
			this->expr1DataGridViewTextBoxColumn->DataPropertyName = L"Expr1";
			this->expr1DataGridViewTextBoxColumn->HeaderText = L"��������";
			this->expr1DataGridViewTextBoxColumn->Name = L"expr1DataGridViewTextBoxColumn";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button5);
			this->groupBox1->Controls->Add(this->dataGridView2);
			this->groupBox1->Controls->Add(this->dataGridView1);
			this->groupBox1->Controls->Add(this->comboBox3);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Location = System::Drawing::Point(6, 3);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(471, 280);
			this->groupBox1->TabIndex = 1;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"��������� �� ���� ��� ��������� ������ � ����� ";
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::SlateGray;
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button5->ForeColor = System::Drawing::Color::White;
			this->button5->Location = System::Drawing::Point(289, 13);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(173, 38);
			this->button5->TabIndex = 12;
			this->button5->Text = L"³������������";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm4::button5_Click);
			// 
			// dataGridView2
			// 
			this->dataGridView2->AutoGenerateColumns = false;
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(6) {
				this->idzakazuDataGridViewTextBoxColumn,
					this->dataDataGridViewTextBoxColumn, this->idoficiantDataGridViewTextBoxColumn, this->oplachenDataGridViewTextBoxColumn, this->idstilDataGridViewTextBoxColumn,
					this->summaDataGridViewTextBoxColumn
			});
			this->dataGridView2->DataMember = L"zakazu";
			this->dataGridView2->DataSource = this->dataSet1;
			this->dataGridView2->Location = System::Drawing::Point(17, 113);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->Size = System::Drawing::Size(233, 84);
			this->dataGridView2->TabIndex = 9;
			this->dataGridView2->Visible = false;
			// 
			// idzakazuDataGridViewTextBoxColumn
			// 
			this->idzakazuDataGridViewTextBoxColumn->DataPropertyName = L"id_zakazu";
			this->idzakazuDataGridViewTextBoxColumn->HeaderText = L"id_zakazu";
			this->idzakazuDataGridViewTextBoxColumn->Name = L"idzakazuDataGridViewTextBoxColumn";
			// 
			// dataDataGridViewTextBoxColumn
			// 
			this->dataDataGridViewTextBoxColumn->DataPropertyName = L"data";
			this->dataDataGridViewTextBoxColumn->HeaderText = L"data";
			this->dataDataGridViewTextBoxColumn->Name = L"dataDataGridViewTextBoxColumn";
			// 
			// idoficiantDataGridViewTextBoxColumn
			// 
			this->idoficiantDataGridViewTextBoxColumn->DataPropertyName = L"id_oficiant";
			this->idoficiantDataGridViewTextBoxColumn->HeaderText = L"id_oficiant";
			this->idoficiantDataGridViewTextBoxColumn->Name = L"idoficiantDataGridViewTextBoxColumn";
			// 
			// oplachenDataGridViewTextBoxColumn
			// 
			this->oplachenDataGridViewTextBoxColumn->DataPropertyName = L"oplachen";
			this->oplachenDataGridViewTextBoxColumn->HeaderText = L"oplachen";
			this->oplachenDataGridViewTextBoxColumn->Name = L"oplachenDataGridViewTextBoxColumn";
			// 
			// idstilDataGridViewTextBoxColumn
			// 
			this->idstilDataGridViewTextBoxColumn->DataPropertyName = L"id_stil";
			this->idstilDataGridViewTextBoxColumn->HeaderText = L"id_stil";
			this->idstilDataGridViewTextBoxColumn->Name = L"idstilDataGridViewTextBoxColumn";
			// 
			// summaDataGridViewTextBoxColumn
			// 
			this->summaDataGridViewTextBoxColumn->DataPropertyName = L"summa";
			this->summaDataGridViewTextBoxColumn->HeaderText = L"summa";
			this->summaDataGridViewTextBoxColumn->Name = L"summaDataGridViewTextBoxColumn";
			// 
			// comboBox3
			// 
			this->comboBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(8) {
				L"����� �� г�����", L"������� �������", L"������ �������",
					L"������ NEW", L"������ �\'���� ������", L"����� ������", L"����", L"�������"
			});
			this->comboBox3->Location = System::Drawing::Point(110, 19);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(173, 28);
			this->comboBox3->TabIndex = 11;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(2, 22);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(102, 20);
			this->label4->TabIndex = 10;
			this->label4->Text = L"��������: ";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(7, 292);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(180, 20);
			this->label1->TabIndex = 3;
			this->label1->Text = L"C���� ����������: ";
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->textBox1->Location = System::Drawing::Point(205, 289);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(173, 26);
			this->textBox1->TabIndex = 4;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::DarkGreen;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Location = System::Drawing::Point(-3, 395);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(367, 35);
			this->button1->TabIndex = 5;
			this->button1->Text = L"�����";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm4::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::DarkRed;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button2->ForeColor = System::Drawing::Color::White;
			this->button2->Location = System::Drawing::Point(361, 395);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(384, 35);
			this->button2->TabIndex = 6;
			this->button2->Text = L"�����";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm4::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::DarkCyan;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button3->ForeColor = System::Drawing::Color::White;
			this->button3->Location = System::Drawing::Point(394, 292);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(172, 97);
			this->button3->TabIndex = 7;
			this->button3->Text = L"�������� ����������";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm4::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::Goldenrod;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->button4->ForeColor = System::Drawing::Color::White;
			this->button4->Location = System::Drawing::Point(572, 292);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(159, 97);
			this->button4->TabIndex = 8;
			this->button4->Text = L"³������";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm4::button4_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(8, 324);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(127, 20);
			this->label2->TabIndex = 10;
			this->label2->Text = L"����� �����: ";
			// 
			// comboBox1
			// 
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(14) {
				L"1 - ������� ���", L"2 - ������� ���", L"1 - ������",
					L"2 - ������", L"3 - ������", L"4 - ������", L"5 - ������", L"1 - ����� ���", L"2 - ����� ���", L"3 - ����� ���", L"1 - ���������� ",
					L"2 - ���������� ", L"3 - ���������� ", L"4 - ���������� "
			});
			this->comboBox1->Location = System::Drawing::Point(205, 321);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(173, 28);
			this->comboBox1->TabIndex = 11;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(7, 358);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(96, 20);
			this->label3->TabIndex = 12;
			this->label3->Text = L"��������: ";
			// 
			// comboBox2
			// 
			this->comboBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"������ �.�.", L"���� �.�." });
			this->comboBox2->Location = System::Drawing::Point(205, 355);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(173, 28);
			this->comboBox2->TabIndex = 13;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(483, 12);
			this->textBox2->Multiline = true;
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(248, 265);
			this->textBox2->TabIndex = 14;
			// 
			// dataGridView3
			// 
			this->dataGridView3->AutoGenerateColumns = false;
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->idskladDataGridViewTextBoxColumn,
					this->idingridientDataGridViewTextBoxColumn, this->kilkistDataGridViewTextBoxColumn, this->idvumiruDataGridViewTextBoxColumn
			});
			this->dataGridView3->DataMember = L"sklad";
			this->dataGridView3->DataSource = this->dataSet1;
			this->dataGridView3->Location = System::Drawing::Point(493, 67);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->Size = System::Drawing::Size(218, 130);
			this->dataGridView3->TabIndex = 15;
			this->dataGridView3->Visible = false;
			// 
			// idskladDataGridViewTextBoxColumn
			// 
			this->idskladDataGridViewTextBoxColumn->DataPropertyName = L"id_sklad";
			this->idskladDataGridViewTextBoxColumn->HeaderText = L"id_sklad";
			this->idskladDataGridViewTextBoxColumn->Name = L"idskladDataGridViewTextBoxColumn";
			// 
			// idingridientDataGridViewTextBoxColumn
			// 
			this->idingridientDataGridViewTextBoxColumn->DataPropertyName = L"id_ingridient";
			this->idingridientDataGridViewTextBoxColumn->HeaderText = L"id_ingridient";
			this->idingridientDataGridViewTextBoxColumn->Name = L"idingridientDataGridViewTextBoxColumn";
			// 
			// kilkistDataGridViewTextBoxColumn
			// 
			this->kilkistDataGridViewTextBoxColumn->DataPropertyName = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn->HeaderText = L"kilkist";
			this->kilkistDataGridViewTextBoxColumn->Name = L"kilkistDataGridViewTextBoxColumn";
			// 
			// idvumiruDataGridViewTextBoxColumn
			// 
			this->idvumiruDataGridViewTextBoxColumn->DataPropertyName = L"id_vumiru";
			this->idvumiruDataGridViewTextBoxColumn->HeaderText = L"id_vumiru";
			this->idvumiruDataGridViewTextBoxColumn->Name = L"idvumiruDataGridViewTextBoxColumn";
			// 
			// MyForm4
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(736, 429);
			this->Controls->Add(this->dataGridView3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->groupBox1);
			this->Name = L"MyForm4";
			this->Text = L"��������� ����������";
			this->Load += gcnew System::EventHandler(this, &MyForm4::MyForm4_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataSet1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataTable3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		// ������
		double sum;
	private: System::Void MyForm4_Load(System::Object^  sender, System::EventArgs^  e) { // �������� �����
		this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
			L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
			L"y = kategory.id_kategory)";
		oleDbDataAdapter1->Fill(dataTable1);
		this->oleDbSelectCommand1->CommandText = L"SELECT        id_zakazu, data, id_oficiant, oplachen, id_stil, summa\r\nFROM       "
			L"     zakazu";
		oleDbDataAdapter1->Fill(dataTable2);

		this->oleDbSelectCommand1->CommandText = L"SELECT        id_sklad, id_ingridient, kilkist, id_vumiru\r\nFROM            sklad";
		oleDbDataAdapter1->Fill(dataTable3);
	}
	private: System::Void dataGridView1_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) { // ������� ������� ���� �� �������
		String^ n;
		int j;
		int k;
		int n2;
		j = dataGridView1->CurrentRow->Index;
		k = dataGridView1->CurrentCell->ColumnIndex;
		n = (String^)dataGridView1->Rows[j]->Cells[1]->Value + " - " + (String^)dataGridView1->Rows[j]->Cells[2]->Value;
		textBox2->Text += Environment::NewLine + n;
		
		dataTable3->Clear();
		this->oleDbSelectCommand1->CommandText = L"SELECT        id_sklad, id_ingridient, kilkist, id_vumiru\r\nFROM            sklad";
		oleDbDataAdapter1->Fill(dataTable3);

		n2 = Convert::ToInt32((String^)dataGridView1->Rows[j]->Cells[0]->Value);
		this->oleDbSelectCommand1->CommandText = L" SELECT        sklad.id_sklad, sklad.id_ingridient, sklad.kilkist, sklad.id_vumiru "
			L" FROM(((menu INNER JOIN "
			L" sklad_stravu ON menu.id_stravu = sklad_stravu.strava) INNER JOIN "
			L" 	ingridient ON sklad_stravu.ingridient = ingridient.id_ingridient) INNER JOIN "
			L" 	sklad ON ingridient.id_ingridient = sklad.id_sklad) "
			L" WHERE(menu.id_stravu = "+n2+") ";
		dataTable3->Clear();
		oleDbDataAdapter1->Fill(dataTable3);

		int colstr = 0;
		colstr = dataGridView3->RowCount;
		for (int b = 0; b < colstr-1; b++)
		{
			int m = 0;
			m = Convert::ToInt32(dataGridView3->Rows[b]->Cells[2]->Value);

			if(m>0)m = m - 1;
			else
			{
				String^ message = "�� ������� ����䳺��� �� �����! ³������ �����.";
				String^ caption = "�����";
				MessageBoxButtons buttons = MessageBoxButtons::OK;
				System::Windows::Forms::DialogResult result;
				result = MessageBox::Show(this, message, caption, buttons);

				break;
			}
			dataGridView3->Rows[b]->Cells[2]->Value = Convert::ToString(m);

			this->oleDbUpdateCommand1->CommandText = L"UPDATE       sklad\r\nSET               kilkist = " + m + " WHERE        (id_sklad = " + dataGridView3->Rows[b]->Cells[0]->Value + ")";
			oleDbConnection1->Open();
			oleDbDataAdapter1->UpdateCommand->ExecuteNonQuery();
			oleDbConnection1->Close();
		}

		sum = sum + Convert::ToDouble((String^)dataGridView1->Rows[j]->Cells[2]->Value);
		textBox1->Text = Convert::ToString(sum);
	}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {// ������ �����
	Application::Exit();
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {// ������ �����
	this->Hide();               // �������� �����
	Form^ form = this->Owner;  // �������� ��������� �� ��������� 
	form->Show();
}
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) { //������ ������
	textBox2->Clear();
	textBox1->Text = "";
	comboBox1->Text = "";
	comboBox2->Text = "";
}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {// ������ ������� �����


	oleDbDataAdapter1->InsertCommand->Parameters["id_oficiant"]->Value = comboBox2->SelectedIndex + 1;
	oleDbDataAdapter1->InsertCommand->Parameters["oplachen"]->Value = "true";
	oleDbDataAdapter1->InsertCommand->Parameters["id_stil"]->Value = comboBox1->SelectedIndex + 1;
	oleDbDataAdapter1->InsertCommand->Parameters["summa"]->Value = Convert::ToInt32(textBox1->Text);
	oleDbConnection1->Open();
	oleDbDataAdapter1->InsertCommand->ExecuteNonQuery();
	oleDbConnection1->Close();
	oleDbDataAdapter1->Update(dataSet1->Tables["zakazu"]);
	dataTable2->Clear();
	oleDbDataAdapter1->Fill(dataTable2); 
	
	int kol;
	kol = Convert::ToInt32(dataGridView2->Rows->Count) + 6;
	String^ message = textBox2->Text + Environment::NewLine +"�������� ����: "+ textBox1->Text + Environment::NewLine + "��������: " + comboBox2->Text + Environment::NewLine + "���: " + comboBox1->Text;
	String^ caption = "��� �" + Convert::ToString(kol);
	MessageBoxButtons buttons = MessageBoxButtons::OK;
	System::Windows::Forms::DialogResult result;
	result = MessageBox::Show(this, message, caption, buttons);

	textBox2->Clear();
	textBox1->Text = "";
	comboBox1->Text = "";
	comboBox2->Text = "";
}
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) { // ������� �� ������ �������
	dataTable1->Clear();
	this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
		L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
		L"y = kategory.id_kategory)";
	oleDbDataAdapter1->Fill(dataTable1);
	dataTable1->Clear();
			this->oleDbSelectCommand1->CommandText = L"SELECT        menu.id_stravu, menu.nazva, menu.cina, kategory.nazva AS Expr1\r\nFRO"
			L"M            (menu INNER JOIN\r\n                         kategory ON menu.kategor"
			L"y = kategory.id_kategory)"
			L"WHERE(kategory.nazva = '"+ comboBox3->Text +"')";
			oleDbDataAdapter1->Fill(dataTable1);
}
};
}
